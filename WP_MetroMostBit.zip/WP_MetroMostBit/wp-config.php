<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'wp_metromost');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'n5T4vMxb:go$CI_Z*!qjLC$Jcz#./4e{z*jLBc]wxP$-#JZ4TC<uSwKKW*lT%g*G');
define('SECURE_AUTH_KEY',  'RsKInBB>y.N1-A1OX_m~_uEu2X5J8(F$f`M_6sb}MM9E,R:^7ua_qElZcVEhN7X:');
define('LOGGED_IN_KEY',    '/YWh#u_crnrTj:y.)*%7]qm w@z;_{!%[6,D-<qQzR 3tkJ9_Sbp]X)9Z6S7m-T%');
define('NONCE_KEY',        'wSJ4]E2dt^_nX.|ohQhlArxaQht1$TF.(3]ZBmd;B_45tFRY&xPZ)lV!l3s~8iGc');
define('AUTH_SALT',        'W36=AE[J?:W]e2&@`bQO;6*ff2:?)q]tC]CIt,v`M~JXY_:}BP0yp,-7-I{^pqBt');
define('SECURE_AUTH_SALT', '4[%30LJjF@Q[qSBH6Z>l$Sbr>Ud%o1n(Bv8!m{S;G}<Oa.Z5)1z~5-( adNMq{O%');
define('LOGGED_IN_SALT',   'Lor_T8yn>>b:wl.TOI!2#``Ai[/;BlH(~|#V0p[3SN,<mzT27?L~ArQjWzAvb>T~');
define('NONCE_SALT',       'xTjeMy-LX 1eT%=F)IV-X6mLDWt}:Mw]V7X;m?$dh%[S`aOq2E6E0pTas9~mQWLl');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
